package com.cognizant.medicinestock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class MedicineStockMicroServiceApplicationTests {

	
	@Test
	public void main() {
		MedicineStockMicroServiceApplication.main(new String[] {});
	}
}
