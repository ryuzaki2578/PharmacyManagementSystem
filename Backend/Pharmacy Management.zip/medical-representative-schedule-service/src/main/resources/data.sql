insert into medical_representatives (name, phone_number) values('Medical Representative 1', '9456481521');
insert into medical_representatives (name, phone_number) values('Medical Representative 2', '9811548231');
insert into medical_representatives (name, phone_number) values('Medical Representative 3', '9846874134');